<!doctype html>
<html lang="en">
  <head>
    
              <meta name="csrf-param" content="authenticity_token">
              <meta name="csrf-token" content="OF3DmhLBdNMOLKaINr1QJU0bnzMTNtzIoAQxwC/g/Pkhc5pNcOpWMW5mjFqV6MrVqJB1+MA+SUJpFnb6ea3f1A==">
            
    <title>
      
        Not Found (404)
      
    </title>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge, chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <meta property="og:type" content="website">
<meta property="og:url" content="https://www.moneymakinghomemaker.com/signals/iwl.js">
<meta name="twitter:card" content="summary_large_image">

<meta property="og:title" content="Not Found (404)">
<meta name="twitter:title" content="Not Found (404)">



    
      <link href="https://kajabi-storefronts-production.kajabi-cdn.com/kajabi-storefronts-production/file-uploads/themes/2153944984/settings_images/4fb23ba-8b26-a80-8cb1-8b3c4eb3ffe_Official_MMH_Favicon.png?v=2" rel="shortcut icon" />
    
    <link rel="canonical" href="https://www.moneymakinghomemaker.com/signals/iwl.js" />

    <!-- Google Fonts ====================================================== -->
    
      <link href="//fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic" rel="stylesheet" type="text/css">
    

    <!-- Kajabi CSS ======================================================== -->
    <link rel="stylesheet" media="screen" href="https://kajabi-app-assets.kajabi-cdn.com/assets/core-4d08d258547af8a29fc4738e545ca8e26d95e11b829a9db5a0b36d047fb91843.css" />

    

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.2/css/all.css" crossorigin="anonymous">

    <link rel="stylesheet" media="screen" href="https://kajabi-storefronts-production.kajabi-cdn.com/kajabi-storefronts-production/themes/2153944984/assets/styles.css?1731300078205911" />

    <!-- Customer CSS ====================================================== -->
    <link rel="stylesheet" media="screen" href="https://kajabi-storefronts-production.kajabi-cdn.com/kajabi-storefronts-production/themes/2153944984/assets/overrides.css?1731300078205911" />
    <style>
  /* Custom CSS Added Via Theme Settings */
  /* CSS Overrides go here */
</style>

    <!-- Kajabi Editor Only CSS ============================================ -->
    

    <!-- Header hook ======================================================= -->
    <script type="text/javascript">
  var Kajabi = Kajabi || {};
</script>
<script type="text/javascript">
  Kajabi.currentSiteUser = {
    "id" : "-1",
    "type" : "Guest",
    "contactId" : "",
  };
</script>
<script type="text/javascript">
  Kajabi.theme = {
    activeThemeName: "Hopper",
    previewThemeId: null,
    editor: false
  };
</script>
<!-- Deadline Funnel --><script type="text/javascript" data-cfasync="false">function SendUrlToDeadlineFunnel(e){var r,t,c,a,h,n,o,A,i = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",d=0,l=0,s="",u=[];if(!e)return e;do r=e.charCodeAt(d++),t=e.charCodeAt(d++),c=e.charCodeAt(d++),A=r<<16|t<<8|c,a=A>>18&63,h=A>>12&63,n=A>>6&63,o=63&A,u[l++]=i.charAt(a)+i.charAt(h)+i.charAt(n)+i.charAt(o);while(d<e.length);s=u.join("");var C=e.length%3;var decoded = (C?s.slice(0,C-3):s)+"===".slice(C||3);decoded = decoded.replace("+", "-");decoded = decoded.replace("/", "_");return decoded;} var dfUrl = SendUrlToDeadlineFunnel(location.href); var dfParentUrlValue;try {dfParentUrlValue = window.parent.location.href;} catch(err) {if(err.name === "SecurityError") {dfParentUrlValue = document.referrer;}}var dfParentUrl = (parent !== window) ? ("/" + SendUrlToDeadlineFunnel(dfParentUrlValue)) : "";(function() {var s = document.createElement("script");s.type = "text/javascript";s.async = true;s.setAttribute("data-scriptid", "dfunifiedcode");s.src ="https://a.deadlinefunnel.com/unified/reactunified.bundle.js?userIdHash=eyJpdiI6IkJjN1hYNEtwa2F5dlhkcHcxbm9Ra3c9PSIsInZhbHVlIjoiV1N5TGZ0SlBIbmlaazZWNTNyNHhlZz09IiwibWFjIjoiNjMyYjQ2NjJmNjg2MjgwZDA4MmQ1YTM3MjY3MzllYTU4YzE2YzkyNDFiNGVhZTNjNzIxNTg3MmIxZmIzNzIyOCJ9&pageFromUrl="+dfUrl+"&parentPageFromUrl="+dfParentUrl;var s2 = document.getElementsByTagName("script")[0];s2.parentNode.insertBefore(s, s2);})();</script><!-- End Deadline Funnel --><script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)
},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
ga('create', 'UA-211581000-1', 'auto', {});
ga('send', 'pageview');
</script>
<style type="text/css">
  #editor-overlay {
    display: none;
    border-color: #2E91FC;
    position: absolute;
    background-color: rgba(46,145,252,0.05);
    border-style: dashed;
    border-width: 3px;
    border-radius: 3px;
    pointer-events: none;
    cursor: pointer;
    z-index: 10000000000;
  }
  .editor-overlay-button {
    color: white;
    background: #2E91FC;
    border-radius: 2px;
    font-size: 13px;
    margin-left: -24px;
    margin-top: -12px;
    padding: 3px 10px;
    text-transform:uppercase;
    font-weight:bold;
    letter-spacing:1.5px;

    left: 50%;
    top: 50%;
    position: absolute;
  }
</style>
      <script type="text/javascript">
        if (typeof (window.rudderanalytics) === "undefined") {
          !function(){"use strict";window.RudderSnippetVersion="3.0.3";var sdkBaseUrl="https://cdn.rudderlabs.com/v3"
          ;var sdkName="rsa.min.js";var asyncScript=true;window.rudderAnalyticsBuildType="legacy",window.rudderanalytics=[]
          ;var e=["setDefaultInstanceKey","load","ready","page","track","identify","alias","group","reset","setAnonymousId","startSession","endSession","consent"]
          ;for(var n=0;n<e.length;n++){var t=e[n];window.rudderanalytics[t]=function(e){return function(){
          window.rudderanalytics.push([e].concat(Array.prototype.slice.call(arguments)))}}(t)}try{
          new Function('return import("")'),window.rudderAnalyticsBuildType="modern"}catch(a){}
          if(window.rudderAnalyticsMount=function(){
          "undefined"==typeof globalThis&&(Object.defineProperty(Object.prototype,"__globalThis_magic__",{get:function get(){
          return this},configurable:true}),__globalThis_magic__.globalThis=__globalThis_magic__,
          delete Object.prototype.__globalThis_magic__);var e=document.createElement("script")
          ;e.src="".concat(sdkBaseUrl,"/").concat(window.rudderAnalyticsBuildType,"/").concat(sdkName),e.async=asyncScript,
          document.head?document.head.appendChild(e):document.body.appendChild(e)
          },"undefined"==typeof Promise||"undefined"==typeof globalThis){var d=document.createElement("script")
          ;d.src="https://polyfill-fastly.io/v3/polyfill.min.js?version=3.111.0&features=Symbol%2CPromise&callback=rudderAnalyticsMount",
          d.async=asyncScript,document.head?document.head.appendChild(d):document.body.appendChild(d)}else{
          window.rudderAnalyticsMount()}window.rudderanalytics.load("2apYBMHHHWpiGqicceKmzPebApa","https://kajabiaarnyhwq.dataplane.rudderstack.com",{})}();
        }
      </script>
      <script type="text/javascript">
        const payload = {"account_id":"2147516887","site_id":"2147536127"};
        if (typeof (window.rudderanalytics) !== "undefined") {
          rudderanalytics.page(payload);

          // Function to handle link clicks and send track event
          function AnalyticsLinkClick(event) {
            if (!event.target.closest('a')) return; // If the click is not on a link, return early

            const link = event.target;
            const href = link.href;
            const linkText = link.textContent.trim();
            payload.link_text = linkText;
            payload.link_href = href;

            rudderanalytics.track('Site Link Clicked', payload);
          }

          // Attach click event listener
          document.addEventListener('click', AnalyticsLinkClick);
        }
      </script>
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.agent='plkajabi';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
                                                                      document,'script','https://connect.facebook.net/en_US/fbevents.js');


fbq('init', '408446500731339', {"ct":"!KJB_CONTACT_ADDRESS_CITY!","country":null,"em":"!KJB_CONTACT_EMAIL!","fn":"!KJB_CONTACT_FIRST_NAME!","ln":"!KJB_CONTACT_LAST_NAME!","pn":"","zp":"!KJB_CONTACT_ADDRESS_ZIP!"});
fbq('track', "PageView");</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=408446500731339&ev=PageView&noscript=1"
/></noscript>
<meta name='site_locale' content='en'><style type="text/css">
  body main {
    direction: ltr;
  }
  .slick-list {
    direction: ltr;
  }
</style>
<style type="text/css">
  /* Font Awesome 4 */
  .fa.fa-twitter{
    font-family:sans-serif;
  }
  .fa.fa-twitter::before{
    content:"𝕏";
    font-size:1.2em;
  }

  /* Font Awesome 5 */
  .fab.fa-twitter{
    font-family:sans-serif;
  }
  .fab.fa-twitter::before{
    content:"𝕏";
    font-size:1.2em;
  }
</style>


  </head>
  <style>
  body {
    
      
    
  }
</style>
  <body class="background-unrecognized">
    <main>
      
<div id="section-header" data-section-id="header">

<style>
  /* Default Header Styles */
  .header {
    
      background-color: #ffffff;
    
    font-size: 18px;
  }
  .header a,
  .header a.link-list__link,
  .header a.link-list__link:hover,
  .header a.social-icons__icon,
  .header .user__login a,
  .header .dropdown__item a,
  .header .dropdown__trigger:hover {
    color: #000000;
  }
  .header .dropdown__trigger {
    color: #000000 !important;
  }
  /* Mobile Header Styles */
  @media (max-width: 767px) {
    .header {
      
        background-color: #ffffff;
      
      font-size: 16px;
    }
    
      .header a,
      .header a.link-list__link,
      .header a.social-icons__icon,
      .header .dropdown__item a,
      .header .user__login a,
      .header a.link-list__link:hover,
      .header .dropdown__trigger:hover {
        color: #000000;
      }
      .header .dropdown__trigger {
        color: #000000 !important;
      }
    
    .header .hamburger__slices .hamburger__slice {
      
        background-color: #000000;
      
    }
    
      .header a.link-list__link, .dropdown__item a, .header__content--mobile {
        text-align: center;
      }
    
    .header--overlay .header__content--mobile  {
      padding-bottom: 20px;
    }
  }
  /* Sticky Styles */
  
</style>

<div class="hidden">
  
    
  
    
  
    
  
  
  
  
</div>

<header class="header header--overlay    background-light header--close-on-scroll" kjb-settings-id="sections_header_settings_background_color">
  <div class="hello-bars">
    
      
    
      
    
      
    
  </div>
  
    <div class="header__wrap">
      <div class="header__content header__content--desktop background-light">
        <div class="container header__container media justify-content-right">
          
            
                <style>
@media (min-width: 768px) {
  #block-1693934104160 {
    text-align: left;
  }
} 
</style>

<div id="block-1693934104160" class="header__block header__block--logo header__block--show header__switch-content " kjb-settings-id="sections_header_blocks_1693934104160_settings_stretch">
  <style>
  #block-1693934104160 {
    line-height: 1;
  }
  #block-1693934104160 .logo__image {
    display: block;
    width: 180px;
  }
  #block-1693934104160 .logo__text {
    color: ;
  }
</style>

<a class="logo" href="/">
  
    
      <img class="logo__image" src="https://kajabi-storefronts-production.kajabi-cdn.com/kajabi-storefronts-production/file-uploads/themes/2153944984/settings_images/a3d3fbf-4c83-8e83-e2d2-a6fa0820d35_MMH_Official_Logo.png" kjb-settings-id="sections_header_blocks_1693934104160_settings_logo" alt="Header Logo" />
    
  
</a>
</div>
              
          
            
                <style>
@media (min-width: 768px) {
  #block-1686254741981 {
    text-align: right;
  }
} 
</style>

<div id="block-1686254741981" class="header__block header__switch-content header__block--menu stretch" kjb-settings-id="sections_header_blocks_1686254741981_settings_stretch">
  <div class="link-list justify-content-right" kjb-settings-id="sections_header_blocks_1686254741981_settings_menu">
  
    <a class="link-list__link" href="https://www.moneymakinghomemaker.com/library" >Library</a>
  
</div>
</div>
              
          
            
                <style>
@media (min-width: 768px) {
  #block-1686252467743 {
    text-align: center;
  }
} 
</style>

<div id="block-1686252467743" class="header__block header__switch-content header__block--user " kjb-settings-id="sections_header_blocks_1686252467743_settings_stretch">
  <style>
  /* Dropdown menu colors for desktop */
  @media (min-width: 768px) {
    #block-1686252467743 .dropdown__menu {
      background: #FFFFFF;
      color: #595959;
    }
    #block-1686252467743 .dropdown__item a, 
    #block-1686252467743 {
      color: #595959;
    }
  }  
  /* Mobile menu text alignment */
  @media (max-width: 767px) {
    #block-1686252467743 .dropdown__item a,
    #block-1686252467743 .user__login a {
      text-align: center;
    }
  }
</style>

<div class="user" kjb-settings-id="sections_header_blocks_1686252467743_settings_language_login">
  
    <span class="user__login" kjb-settings-id="language_login"><a href="/login">Login</a></span>
  
</div>
</div>
              
          
          
            <div class="hamburger hidden--desktop" kjb-settings-id="sections_header_settings_hamburger_color">
              <div class="hamburger__slices">
                <div class="hamburger__slice hamburger--slice-1"></div>
                <div class="hamburger__slice hamburger--slice-2"></div>
                <div class="hamburger__slice hamburger--slice-3"></div>
                <div class="hamburger__slice hamburger--slice-4"></div>
              </div>
            </div>
          
        </div>
      </div>
      <div class="header__content header__content--mobile">
        <div class="header__switch-content header__spacer"></div>
      </div>
    </div>
  
</header>

</div>
<div data-dynamic-sections=404><div id="section-1593045036549" data-section-id="1593045036549"><style>
  
  #section-1593045036549 .section__overlay {
    position: absolute;
    width: 100%;
    height: 100%;
    left: 0;
    top: 0;
    background-color: #ffffff;
  }
  #section-1593045036549 .sizer {
    padding-top: 40px;
    padding-bottom: 40px;
  }
  #section-1593045036549 .container {
    max-width: calc(1260px + 10px + 10px);
    padding-right: 10px;
    padding-left: 10px;
    
  }
  #section-1593045036549 .row {
    
  }
  #section-1593045036549 .container--full {
    width: 100%;
    max-width: calc(100% + 10px + 10px);
  }
  @media (min-width: 768px) {
    
    #section-1593045036549 .sizer {
      padding-top: 100px;
      padding-bottom: 100px;
    }
    #section-1593045036549 .container {
      max-width: calc(1260px + 40px + 40px);
      padding-right: 40px;
      padding-left: 40px;
    }
    #section-1593045036549 .container--full {
      max-width: calc(100% + 40px + 40px);
    }
  }
  
  
</style>

<section kjb-settings-id="sections_1593045036549_settings_background_color"
  class="section
  
  
   background-light "
  data-reveal-event=""
  data-reveal-offset=""
  data-reveal-units="seconds">
  <div class="sizer sizer--full">
    
    <div class="section__overlay"></div>
    <div class="container ">
      <div class="row align-items-center justify-content-center">
        
          




<style>
  /* flush setting */
  
  
  /* margin settings */
  #block-1593045036549_0, [data-slick-id="1593045036549_0"] {
    margin-top: 0px;
    margin-right: 0px;
    margin-bottom: 0px;
    margin-left: 0px;
  }
  #block-1593045036549_0 .block, [data-slick-id="1593045036549_0"] .block {
    /* border settings */
    border: 4px none black;
    border-radius: 4px;
    

    /* background color */
    
    /* default padding for mobile */
    
    
    
    /* mobile padding overrides */
    
    
    
    
    
  }

  @media (min-width: 768px) {
    /* desktop margin settings */
    #block-1593045036549_0, [data-slick-id="1593045036549_0"] {
      margin-top: 0px;
      margin-right: 0px;
      margin-bottom: 0px;
      margin-left: 0px;
    }
    #block-1593045036549_0 .block, [data-slick-id="1593045036549_0"] .block {
      /* default padding for desktop  */
      
      
      /* desktop padding overrides */
      
      
      
      
      
    }
  }
  /* mobile text align */
  @media (max-width: 767px) {
    #block-1593045036549_0, [data-slick-id="1593045036549_0"] {
      text-align: center;
    }
  }
</style>


<div
  id="block-1593045036549_0"
  class="
  block-type--text
  text-center
  col-6
  
  
  
    
  
  
  "
  
  data-reveal-event=""
  data-reveal-offset=""
  data-reveal-units="seconds"
  
    kjb-settings-id="sections_1593045036549_blocks_1593045036549_0_settings_width"
    >
  <div class="block
    box-shadow-none
    "
    
      data-aos="none"
      data-aos-delay="0"
      data-aos-duration="0"
    
    >
    
    <style>
  
  #block-1577982541036_0 .btn {
    margin-top: 1rem;
  }
</style>

<h1>Page not found</h1>
<p>The page you are looking for doesn't exist or has been moved.</p>

    






<style>
  #block-1593045036549_0 .btn,
  [data-slick-id="1593045036549_0"] .block .btn {
    color: #ffffff;
    border-color: #8e44ad;
    border-radius: 5px;
    background-color: #8e44ad;
  }
  #block-1593045036549_0 .btn--outline,
  [data-slick-id="1593045036549_0"] .block .btn--outline {
    background: transparent;
    color: #8e44ad;
  }
</style>



  



  
<a class="btn btn--solid btn--large btn--auto" href="/"   kjb-settings-id="sections_1593045036549_blocks_1593045036549_0_settings_btn_background_color" role="button">
  
    BACK TO HOME
  
</a>


  
  </div>
</div>

        
      </div>
    </div>
  </div>
</section>
</div></div>
<div id="section-footer" data-section-id="footer">
  <style>
    #section-footer {
      -webkit-box-flex: 1;
      -ms-flex-positive: 1;
      flex-grow: 1;
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
    }
    .footer {
      -webkit-box-flex: 1;
      -ms-flex-positive: 1;
      flex-grow: 1;
    }
  </style>

<style>
  .footer {
    background-color: #ffffff;
  }
  .footer, .footer__block {
    font-size: 16px;
    color: #000000;
  }
  .footer .logo__text {
    color: ;
  }
  .footer .link-list__links {
    width: 100%;
  }
  .footer a.link-list__link {
    color: #000000;
  }
  .footer .link-list__link:hover {
    color: #000000;
  }
  .copyright {
    color: #000000;
  }
  @media (min-width: 768px) {
    .footer, .footer__block {
      font-size: 18px;
    }
  }
  .powered-by a {
    color: #7f8ea1 !important;
  }
  
    .powered-by {
      text-align: center;
      padding-top: 0;
    }
  
</style>

<footer class="footer footer--stacked  background-light  " kjb-settings-id="sections_footer_settings_background_color">
  <div class="footer__content">
    <div class="container footer__container media">
      
        
            <div id="block-1555988525205" class="footer__block ">
  <span class="copyright" kjb-settings-id="sections_footer_blocks_1555988525205_settings_copyright" role="presentation">
  &copy; 2024 Money Making Homemaker
</span>
</div>
          
      
    </div>
    
  </div>

</footer>

</div>



    </main>
    <!-- Javascripts ======================================================= -->
<script charset='ISO-8859-1' src='https://fast.wistia.com/assets/external/E-v1.js'></script>
<script charset='ISO-8859-1' src='https://fast.wistia.com/labs/crop-fill/plugin.js'></script>
<script src="https://kajabi-app-assets.kajabi-cdn.com/assets/encore_core-f4735cadef603151d28ba781c6a9b7e0fbd3e895347360bf76166481afeacf15.js"></script>
<script src="https://kajabi-storefronts-production.kajabi-cdn.com/kajabi-storefronts-production/themes/2153944984/assets/scripts.js?1731300078205911"></script>



<!-- Customer JS ======================================================= -->
<script>
  /* Custom JS Added Via Theme Settings */
  /* Javascript code goes here */
</script>
  </body>
</html>